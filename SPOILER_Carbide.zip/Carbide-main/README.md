<div align="center">

# Carbide &middot; Discord Bot

# About

**Carbide** is a **Discord Bot** made by [Tornado](https://twitter.com/im2rnadoo) that let's you login to your Fortnite account and access lots of commands! The main bot is at [Carbide](https://github.com/im2rnado/Carbide-Help) and this is just the open-source version of it (less features)
</div>

# Features

- Buy from the item shop
- Gift from the item shop
- Show your Account Name
- Show your Account ID
- Show your V-Bucks
- Claim your Daily STW Reward
- Show your Locker
- Change V-Bucks Platform
- Change SAC Code
- Get friends list
- Add a friend
- Remove a friend
- Change your Homebase Name
- Show your Party Hub Avatar
- Show the current shop
- And tons of more features that get added frequently!

# Installation 

1. Install the stable version of **[Node.JS](https://nodejs.org/en/download/)**
2. Download the source code.
3. Extract the zip.
4. Open `install.bat` and wait for it to install. (Only required on the first run!)
5. [Create](https://discord.com/developers/applications) a Discord Bot account.
6. Navigate to the bot window, copy the token. Remember to **NOT** share the token with anybody! This will result in your bot account being compromised.
7. Make a file called `.env` and put in this:\
`DISCORD_TOKEN=token_you_copied`\
`PREFIX=+`
8. Go to [this](https://discordapi.com/permissions.html) website.
9. Insert your bot's Client ID.

<td align="left"><a href="https://cdn.discordapp.com/attachments/745424999996719166/745676588414402621/botIcon.png"><img src="https://cdn.discordapp.com/attachments/748522409371631688/749382248280883310/Screenshot_2020-08-29_at_22.37.23.png" width="1000px;" alt=""/><br /><sub><b></b></sub></a><br /><a title=""></a></td>

10. Click on the link, invite the bot to one of your servers.
11. Open `run.bat`, it should say `Online!` (DON'T CLOSE THIS WHILE USING THE BOT!)
12. Use the bot!

# Support
For any support, join [discord.gg/5pKvUpA](https://discord.gg/5pKvUpA)

# Disclaimer
This project is **NOT** affiliated, associated, authorized, endorsed by, or in any way official related to Epic Games Inc.
Portions of the materials used are trademarks and/or copyrighted works of Epic Games, Inc.

# Credits
## Contributers
 * [Mix](https://twitter.com/tonxim) - Endpoints
 * [tb24](https://twitter.com/amrsatrio) - Endpoints
 * [Tector](https://mobile.twitter.com/TectorTruck) - Auth Example
## Libraries/APIs
 * [Axios](https://www.npmjs.com/package/axios) - Requests
 * [FortniteAPI.io](https://fortniteapi.io) - Shop and Items
 * [Canvas](https://www.npmjs.com/package/canvas) - Images

### Made by im2rnado

#### If you want this taken down, email me with an official Epic Games email at im2rnado@gmail.com
